package com.quinn.congresstracker


data class BillDetailResponse(
    val status: String,
    val bill: Bill
)
