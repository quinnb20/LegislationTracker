package com.quinn.congresstracker

import android.app.AlertDialog
import android.content.Context
import android.util.Log
import android.widget.Toast
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject

object BillDetailHelper {

    fun fetchBillDetails(context: Context, billId: Int) {
        val apiKey = "98a26c1854a2730f31cf14ec620af23e"
        val url = "https://api.legiscan.com/?key=$apiKey&op=getBill&id=$billId"

        CoroutineScope(Dispatchers.IO).launch {
            try {
                val client = OkHttpClient()
                val request = Request.Builder().url(url).build()
                val response = client.newCall(request).execute()

                if (response.isSuccessful) {
                    val responseData = response.body()?.string()
                    withContext(Dispatchers.Main) {
                        parseBillDetails(context, responseData)
                    }
                } else {
                    withContext(Dispatchers.Main) {
                        Toast.makeText(context, "Error fetching bill", Toast.LENGTH_SHORT).show()
                    }
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    Toast.makeText(context, "Network error: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun parseBillDetails(context: Context, json: String?) {
        if (json.isNullOrEmpty()) return

        try {
            val billObj = JSONObject(json).getJSONObject("bill")

            // Sponsors section
            val sponsorsList = billObj.optJSONArray("sponsors")
            val sponsors = StringBuilder("Sponsors:\n")
            if (sponsorsList != null && sponsorsList.length() > 0) {
                for (i in 0 until sponsorsList.length()) {
                    val sponsor = sponsorsList.getJSONObject(i)
                    sponsors.append("- ${sponsor.getString("name")} (${sponsor.getString("party")})\n")
                }
            } else {
                sponsors.append("No sponsors available")
            }

            // Votes section
            val votesList = billObj.optJSONArray("votes")
            val votes = StringBuilder("Votes:\n")
            if (votesList != null && votesList.length() > 0) {
                for (i in 0 until votesList.length()) {
                    val vote = votesList.getJSONObject(i)
                    votes.append("- ${vote.getString("motion")} on ${vote.getString("date")}: Yes ${vote.getInt("yes")}, No ${vote.getInt("no")}\n")
                }
            } else {
                votes.append("No vote information available")
            }

            val message = sponsors.toString() + "\n\n" + votes.toString()

            AlertDialog.Builder(context)
                .setTitle("Bill Details")
                .setMessage(message)
                .setPositiveButton("OK", null)
                .show()

        } catch (e: Exception) {
            Toast.makeText(context, "Error parsing bill: ${e.message}", Toast.LENGTH_SHORT).show()
            Log.e("BillDetailHelper", "Error parsing bill details", e)
        }
    }
}
