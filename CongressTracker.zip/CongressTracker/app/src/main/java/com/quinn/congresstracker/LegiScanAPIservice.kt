package com.quinn.congresstracker

import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Query

interface LegiScanApiService {

    // Fetches list of bills (summary data)
    @GET(".")
    suspend fun getMasterList(
        @Query("key") apiKey: String,
        @Query("op") operation: String = "getMasterList",
        @Query("state") state: String
    ): Response<MasterListResponse>

    // Fetches detailed bill info (includes sponsors and votes)
    @GET(".")
    suspend fun getBillDetail(
        @Query("key") apiKey: String,
        @Query("op") operation: String = "getBill",
        @Query("id") billId: Int
    ): Response<BillDetailResponse>

}


