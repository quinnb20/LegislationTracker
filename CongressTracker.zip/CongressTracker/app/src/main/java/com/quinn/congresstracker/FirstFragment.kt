package com.quinn.congresstracker

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Spinner
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.launch

class FirstFragment : Fragment() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: BillAdapter
    private lateinit var stateSpinner: Spinner
    private lateinit var messageTextView: TextView

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        return inflater.inflate(R.layout.fragment_first, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        recyclerView = view.findViewById(R.id.recyclerView)
        stateSpinner = view.findViewById(R.id.stateSpinner)
        messageTextView = view.findViewById(R.id.messageTextView)

        recyclerView.layoutManager = LinearLayoutManager(requireContext())
        adapter = BillAdapter(emptyList()) { bill ->
            val detailFragment = BillDetailFragment.newInstance(bill)
            parentFragmentManager.beginTransaction()
                .replace(R.id.fragment_container_view, detailFragment)
                .addToBackStack(null)
                .commit()
        }
        recyclerView.adapter = adapter

        val states = listOf(
            "AL", "AK", "AZ", "AR", "CA", "CO", "CT", "DE", "FL", "GA", "HI", "ID",
            "IL", "IN", "IA", "KS", "KY", "LA", "ME", "MD", "MA", "MI", "MN", "MS",
            "MO", "MT", "NE", "NV", "NH", "NJ", "NM", "NY", "NC", "ND", "OH", "OK",
            "OR", "PA", "RI", "SC", "SD", "TN", "TX", "UT", "VT", "VA", "WA", "WV",
            "WI", "WY"
        )

        val spinnerAdapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_item, states)
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        stateSpinner.adapter = spinnerAdapter

        stateSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: View?, position: Int, id: Long) {
                val selectedState = parent.getItemAtPosition(position) as String
                fetchBills(selectedState)
            }

            override fun onNothingSelected(parent: AdapterView<*>) {}
        }

    }

    // Move fetchBills and parseBills outside of onViewCreated
    private fun fetchBills(state: String) {
        lifecycleScope.launch {
            try {
                messageTextView.visibility = View.GONE
                recyclerView.visibility = View.GONE

                val response = RetrofitInstance.api.getMasterList(
                    apiKey = "98a26c1854a2730f31cf14ec620af23e",
                    state = state
                )

                if (response.isSuccessful) {
                    val bills = parseBills(response.body())
                    if (bills.isNotEmpty()) {
                        adapter = BillAdapter(bills) { bill ->
                            val detailFragment = BillDetailFragment.newInstance(bill)
                            parentFragmentManager.beginTransaction()
                                .replace(R.id.fragment_container_view, detailFragment)
                                .addToBackStack(null)
                                .commit()
                        }
                        recyclerView.adapter = adapter
                        recyclerView.visibility = View.VISIBLE
                    } else {
                        messageTextView.text = "No bills found for $state."
                        messageTextView.visibility = View.VISIBLE
                    }
                } else {
                    messageTextView.text = "API error: ${response.code()}"
                    messageTextView.visibility = View.VISIBLE
                }
            } catch (e: Exception) {
                messageTextView.text = "Error: ${e.message}"
                messageTextView.visibility = View.VISIBLE
                Log.e("FirstFragment", "Exception: ${e.message}", e)
            }
        }
    }
    private fun parseBillFromDetail(detail: BillDetail): Bill {
        return Bill(
            billId = detail.bill_id,
            number = detail.number,
            title = detail.title,
            url = detail.url,
            lastActionDate = detail.last_action_date,
            description = detail.description,
            sponsors = detail.sponsors ?: emptyList(),
            votes = detail.votes ?: emptyList()
        )
    }


    private fun parseBills(response: MasterListResponse?): List<Bill> {
        val list = mutableListOf<Bill>()
        response?.masterList?.forEach { (_, json) ->
            val obj = json.asJsonObject
            try {
                if (obj.has("bill_id")) {
                    val sponsors = mutableListOf<Sponsor>()
                    if (obj.has("sponsors")) {
                        val sponsorsArray = obj.getAsJsonArray("sponsors")
                        for (sponsorJson in sponsorsArray) {
                            val sponsorObj = sponsorJson.asJsonObject
                            sponsors.add(
                                Sponsor(
                                    name = sponsorObj["name"]?.asString ?: "",
                                    party = sponsorObj["party"]?.asString ?: ""
                                )
                            )
                        }
                    }

                    val votes = mutableListOf<Vote>()
                    if (obj.has("votes") && obj["votes"].isJsonArray) {
                        val votesArray = obj.getAsJsonArray("votes")
                        for (voteJson in votesArray) {
                            val voteObj = voteJson.asJsonObject
                            votes.add(
                                Vote(
                                    rollCallId = voteObj["roll_call_id"]?.asInt ?: 0,
                                    date = voteObj["date"]?.asString ?: "",
                                    desc = voteObj["desc"]?.asString ?: "",
                                    yea = voteObj["yea"]?.asInt ?: 0,
                                    nay = voteObj["nay"]?.asInt ?: 0,
                                    nv = voteObj["nv"]?.asInt ?: 0,
                                    absent = voteObj["absent"]?.asInt ?: 0,
                                    total = voteObj["total"]?.asInt ?: 0,
                                    passed = voteObj["passed"]?.asInt ?: 0,
                                    chamber = voteObj["chamber"]?.asString ?: ""
                                )
                            )
                        }
                    }

                    list.add(
                        Bill(
                            billId = obj["bill_id"].asInt,
                            number = obj["number"].asString,
                            title = obj["title"].asString,
                            url = obj["url"].asString,
                            lastActionDate = obj["last_action_date"].asString,
                            description = if (obj.has("description")) obj["description"].asString else null,
                            sponsors = sponsors,
                            votes = votes
                        )
                    )
                }
            } catch (e: Exception) {
                Log.e("parseBills", "Error parsing bill: ${e.message}", e)
            }
        }

        return list.sortedByDescending { it.lastActionDate }.take(40)
    }}


