package com.quinn.congresstracker

data class BillDetail(
    val bill_id: Int,
    val number: String,
    val title: String,
    val url: String,
    val last_action_date: String,
    val description: String?,
    val sponsors: List<Sponsor>?,
    val votes: List<Vote>?
)
