package com.quinn.congresstracker

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

object RetrofitInstance {
    val api: LegiScanApiService by lazy {
        Retrofit.Builder()
            .baseUrl("https://api.legiscan.com/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(LegiScanApiService::class.java)
    }
}
