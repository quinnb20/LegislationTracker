package com.quinn.congresstracker

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.parcelize.Parcelize

@Parcelize
data class Bill(
    @SerializedName("bill_id") val billId: Int,
    val number: String,
    val title: String,
    val url: String,
    @SerializedName("last_action_date") val lastActionDate: String,
    val description: String?,
    val sponsors: List<Sponsor> = emptyList(),
    val votes: List<Vote> = emptyList()
) : Parcelable

@Parcelize
data class Sponsor(
    val name: String,
    val party: String
) : Parcelable

@Parcelize
data class Vote(
    @SerializedName("roll_call_id") val rollCallId: Int,
    val date: String,
    val desc: String,
    val yea: Int,
    val nay: Int,
    val nv: Int,
    val absent: Int,
    val total: Int,
    val passed: Int,
    val chamber: String
) : Parcelable
