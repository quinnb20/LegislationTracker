package com.quinn.congresstracker

import com.google.gson.JsonElement
import com.google.gson.annotations.SerializedName

data class MasterListResponse(
    @SerializedName("masterlist") val masterList: Map<String, JsonElement>
)

