package com.quinn.congresstracker

import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.annotation.RequiresApi
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch

class BillDetailFragment : Fragment() {

    private val TAG = "BillDetailFragment"
    private lateinit var billNumberTextView: TextView
    private lateinit var billTitleTextView: TextView
    private lateinit var billDescriptionTextView: TextView
    private lateinit var lastActionTextView: TextView
    private lateinit var billUrlTextView: TextView
    private lateinit var sponsorsTextView: TextView
    private lateinit var votesTextView: TextView

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_bill_detail, container, false)
    }

    @RequiresApi(Build.VERSION_CODES.TIRAMISU)
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Initialize TextViews
        billNumberTextView = view.findViewById(R.id.billNumber)
        billTitleTextView = view.findViewById(R.id.billTitle)
        billDescriptionTextView = view.findViewById(R.id.billDescription)
        lastActionTextView = view.findViewById(R.id.lastAction)
        billUrlTextView = view.findViewById(R.id.billUrl)
        sponsorsTextView = view.findViewById(R.id.billSponsors)
        votesTextView = view.findViewById(R.id.billVotes)

        val backButton = view.findViewById<Button>(R.id.backButton)
        backButton?.setOnClickListener {
            parentFragmentManager.popBackStack()
        }

        val bill = requireArguments().getParcelable("bill", Bill::class.java)
        if (bill == null) {
            Log.e(TAG, "Bill object is null!")
            return
        }

        // Initial UI population (before fetching detailed data)
        billNumberTextView.text = bill.number
        billTitleTextView.text = bill.title
        billDescriptionTextView.text = bill.description ?: "No description available"
        lastActionTextView.text = bill.lastActionDate
        billUrlTextView.text = bill.url
        sponsorsTextView.text = "Loading sponsor information..."
        votesTextView.text = "Loading vote information..."

        fetchBillDetails(bill.billId)
    }

    private fun fetchBillDetails(billId: Int) {
        lifecycleScope.launch {
            try {
                val response = RetrofitInstance.api.getBillDetail(
                    apiKey = "98a26c1854a2730f31cf14ec620af23e", // replace with your actual key
                    billId = billId
                )

                if (response.isSuccessful) {
                    val detailedBill = response.body()?.bill
                    if (detailedBill != null) {
                        updateUIWithDetails(detailedBill)
                    } else {
                        Log.e(TAG, "Detailed bill is null")
                    }
                } else {
                    Log.e(TAG, "API error: ${response.code()}")
                }
            } catch (e: Exception) {
                Log.e(TAG, "API call failed: ${e.message}")
            }
        }
    }

    private fun updateUIWithDetails(bill: Bill) {
        sponsorsTextView.text = if (bill.sponsors.isEmpty()) {
            "No sponsor information available"
        } else {
            buildString {
                append("Sponsors:\n")
                bill.sponsors.forEach {
                    append("- ${it.name} (${it.party})\n")
                }
            }
        }

        votesTextView.text = if (bill.votes.isEmpty()) {
            "No vote information available"
        } else {
            buildString {
                append("Votes:\n")
                bill.votes.forEach {
                    append("- ${it.desc} on ${it.date}: Yes ${it.yea}, No ${it.nay}\n")
                }
            }
        }
    }

    companion object {
        fun newInstance(bill: Bill): BillDetailFragment {
            val fragment = BillDetailFragment()
            val args = Bundle()
            args.putParcelable("bill", bill)
            fragment.arguments = args
            return fragment
        }
    }
}
